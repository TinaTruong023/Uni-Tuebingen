/*
 * main.cpp
 *
 *  Created on: Dec 5, 2011
 *      Author: Benjamin Resch
 */

#include <fstream>
#include <map>
#include <assert.h>
#include <iostream>
#include "utils/fileio.h"
#include "utils/vec.h"

using namespace std;

map<int, Vec3> loadCMF()
{
	map<int, Vec3> result;

	// TODO 8.1 a) Load the CMF data or hardcode it here.
	// Feel free to modify the return type and parameters if you need.

	// IMPORT .csv-file
	ifstream inFile("../lin2012xyz2e_5_7sf.csv", ios::in);
	if (!inFile.is_open()) cout << "Can't open file!" << endl;

	string readLine;

	/**
	 * @brief READ .csv-file line-by-line to get data
	 */
	while (getline(inFile, readLine)) 
	{
		
		/**
		 * @brief read and convert wavelength vaule
		 * --> found in first data entry, so the content before the first seperator
		 */
		int seperatorPosition = readLine.find(",");
		int wavelength = stoi(readLine.substr(0, seperatorPosition));
		string restOfLine = readLine.substr(seperatorPosition + 1, readLine.size() - 1);
		
		/**
		 * @brief read and convert response value (vector)
		 * --> the next 3 data entries after the wavelength
		 */
		Vec3 response;
		for (int i = 0; i < 3; i++) 
		{
			// find position of next "," --> next seperator
			seperatorPosition = restOfLine.find(",");

			if (seperatorPosition != string::npos) 
			{
				response[i] = stof(restOfLine.substr(0, seperatorPosition));
				restOfLine = restOfLine.substr(seperatorPosition + 1, restOfLine.size() - 1);
			}
			else 
			{
				// at the end there is no seperator, so just read the restOfLine last value for vec
				response[i] = stof(restOfLine);
			}
		}

		result[wavelength] = response;
	}

	// ------- DEBUG PRINT -------
	for (map<int, Vec3>::iterator i = result.begin(); i != result.end(); i++)
		cout << i->first << "\t" << i->second.x << "\t" << i->second.y << "\t" << i->second.z << endl;

	return result;
}

int main(int argc, char** argv)
{	
	// Setup:
	int resX = 512;
	int resY = 256;
	int imgDimension = resX * resY * 3;
	int wavelengthLowerBound = 400;
	int wavelengthUpperBound = 720;

	// variable "result" changed for compatibility with save_image_pfm()
	float *result = new float[imgDimension];
	for (unsigned int i = 0; i < imgDimension; i++) 
		result[i] = 0;

		
	map<int, Vec3> cmf = loadCMF();

	// TODO 8.1 b) Load all env_roof_l???.pfm images and add the response that is caused by them to the result image.
	
	/**
	* @brief Calc. Spectral Image and save it
	*/
	for (int wl_counter = wavelengthLowerBound; wl_counter <= wavelengthUpperBound; wl_counter = wl_counter + 10)
	{
		char filename [40];
		sprintf(filename, "../spectral_roof/env_roof_l%d.pfm", wl_counter);

		float *spectralImage = new float[imgDimension];
		
		bool isLoaded = load_image_pfm(filename, spectralImage, resX, resY);
		if (!isLoaded) 
		{
			cout << filename << " not found!" << endl;
			continue;
		} 

		for (uint pos = 0; pos < imgDimension; pos = pos + 3) 
		{
			float lambda = spectralImage[pos];

			// calc. x,y,z
			result[pos] += lambda * cmf[wl_counter].x;
			result[pos+1] += lambda * cmf[wl_counter].y;
			result[pos+2] += lambda * cmf[wl_counter].z;
		}
	}

	// TODO 8.1 c) Save the resulting image.
	const char filename_spectralImg [20] = "convertedImage.pfm";
	save_image_pfm(filename_spectralImg, result, resX, resY);

	delete[] result;
}