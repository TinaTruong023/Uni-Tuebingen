#include "bvh.h"
#include "rtStructs.h"
#include <assert.h>
#include <cmath>
#include <iostream>
#include <iterator>
#include <type_traits>
#include <utility>
#include <vector>
#include <algorithm>

using namespace std;

BVH::BVH(const Triangle * const tris, const int nTris) :
		tris(tris), nTris(nTris)
{
	nodes = new Node[nTris * 2]; // a bvh has at most 2 * n - 1 nodes

	indices = new int[nTris];
	for (int i = 0; i < nTris; i++)
		indices[i] = i;

	addedNodes = 1; // the root node
	buildBVH(0, 0, nTris, 0);
}

BVH::~BVH()
{
}

void BVH::findSplitPlane(unsigned int* dimension, float* position, const AABB &box)
{
	*dimension = box.getMaxAxis();
	*position = box.getCenter()[*dimension];
}

void BVH::buildBVH(int nodeIndex, int triIndex, int numTris, int depth)
{
	// TODO c) Implement the method by replacing the code below.
	// Rough Steps:
	// - Find the split plane using the method from b)
	// - Sort all triangles belonging to the currently processed node depending on their center's location relative to the split plane.
	// - Recursively call this method to process subnodes.
	// Don't forget about the base case (no split needed)!

	// value declarations
	const int MIN_TRIS_AMOUNT_OF_NODE = 3;
	const int MAX_DEPTHS_OF_TREE = (int) log2(nTris);
	uint dim;
	float pos;

	AABB computeBbox;
	for (int i = triIndex; i < triIndex + numTris; i++) 
		computeBbox.extend( tris[indices[i]].getAABB() );

	// initial node values
	nodes[nodeIndex].bbox = computeBbox;
	nodes[nodeIndex].numTris = 0;
	nodes[nodeIndex].triIndex = -1;

	// termination condition / base case (no split needed)
	if (numTris <= MIN_TRIS_AMOUNT_OF_NODE || depth >= MAX_DEPTHS_OF_TREE)
	{	// create leaf node
		nodes[nodeIndex].left = -1;
		nodes[nodeIndex].right = -1;
		nodes[nodeIndex].triIndex = triIndex;
		nodes[nodeIndex].numTris = numTris;
	}
	else 
	{
		// find split plane
		BVH::findSplitPlane(&dim, &pos, nodes[nodeIndex].bbox);
		
		// sort tris "left" / "right" in relation to splitplane
		std::pair<int, int> amountOfTrisLeft_Right; // <trisInLeft, trisInRight>
		amountOfTrisLeft_Right = sortTris(triIndex, numTris, pos, dim);
		
		// LEFT
		int amountOfTrisLeft = amountOfTrisLeft_Right.first;
		if (amountOfTrisLeft == 0) 
		{	// check if left side is empty
			nodes[nodeIndex].left = -1;
		}
		else 
		{ 	// get left child node index
			addedNodes += 1;
			nodes[nodeIndex].left = addedNodes;
			buildBVH(nodes[nodeIndex].left, triIndex, amountOfTrisLeft, ++depth);
		}

		// RIGHT
		int amountOfTrisRight = amountOfTrisLeft_Right.second;
		if (amountOfTrisRight == 0) 
		{   // check if right site is empty
			nodes[nodeIndex].right = -1;
		}
		else 
		{	// get right child node index
			addedNodes += 1;
			nodes[nodeIndex].right = addedNodes;
			buildBVH(nodes[nodeIndex].right, triIndex + amountOfTrisLeft, amountOfTrisRight, ++depth);
		}
	}
}

HitRec BVH::intersect(const Ray &ray) const
{
	// precompute inverse ray direction for bounding box intersection
	// -> compute only once for bvh travesal
	Vec3 invRayDir(1.0f / ray.dir.x, 1.0f / ray.dir.y, 1.0f / ray.dir.z);

	// index array for ray signs (direction of the ray)
	// -> saving costly if-operations during box intersection and traversal
	unsigned int raySign[3][2];
	raySign[0][0] = invRayDir[0] < 0;
	raySign[1][0] = invRayDir[1] < 0;
	raySign[2][0] = invRayDir[2] < 0;

	raySign[0][1] = invRayDir[0] >= 0;
	raySign[1][1] = invRayDir[1] >= 0;
	raySign[2][1] = invRayDir[2] >= 0;

	HitRec rec;

	// TODO d) instead of intersecting all triangles, traverse the bvh
	// and intersect only the triangles in the leave nodes.
	// Attention: Make sure that hit records and tmin/tmax values are not modified by node intersections!

	float tminInterval = ray.tmin;
	float tmaxInterval = ray.tmax;

	if (!nodes->bbox.intersect(ray, tminInterval, tmaxInterval, invRayDir, raySign)) return rec; 			

	int nodeIndex = 0;
	std::vector<std::pair<int, float>> storage; // <index, tmin>		
	
	while(true) 
	{
		Node currentNode = nodes[nodeIndex];
		
		if (currentNode.triIndex == -1) 
		{	// node is not leaf
			const int LEFT_CHILD = currentNode.left;
			const int RIGHT_CHILD = currentNode.right;

			// saving tmin/tmax values so we don't overwrite them 
			float leftTminInterval = tminInterval;
			float rightTminInterval = tminInterval;
			float leftTmaxInterval = tmaxInterval;
			float rightTmaxInterval = tmaxInterval;
			
			const bool LEFT_CHILD_HIT = nodes[LEFT_CHILD].bbox.intersect(ray, leftTminInterval, leftTmaxInterval, invRayDir, raySign);
			const bool RIGHT_CHILD_HIT = nodes[RIGHT_CHILD].bbox.intersect(ray, rightTminInterval, rightTmaxInterval, invRayDir, raySign);
			
			if (LEFT_CHILD_HIT)
			{
				nodeIndex = LEFT_CHILD;
				if (RIGHT_CHILD_HIT) storage.push_back( std::pair<int, float>(RIGHT_CHILD, rightTminInterval) );
				continue;
			}
			else if (RIGHT_CHILD_HIT)
			{
				nodeIndex = RIGHT_CHILD;
				continue;
			}
		}
		else 
		{	// node is leaf --> check intersection with triangles
			for (int i = currentNode.triIndex; i < currentNode.triIndex + currentNode.numTris; i++) 
				tris[indices[i]].intersect(ray, rec, indices[i]);
		}

		while (true) 
		{
			if (storage.size() == 0) return rec;

			std::pair<int, float> storedNode = storage.at(storage.size() - 1);
			storage.pop_back();

			if (storedNode.second <= rec.dist)
			{ 
				nodeIndex = storedNode.first;
				tmaxInterval = minf(tmaxInterval, rec.dist);
				break;
			}
		}
	}
	return rec;
}

std::pair<int, int> BVH::sortTris(const int triIndex, const int numTris, float pos, int dim) 
{
	int left = 0;
	// we save the center (in given plane) of tri with the index that corresponds to this tri
	std::vector<std::pair<int, float>> sortedTrisByCenter; // <index, center>

	for (int i = triIndex; i < triIndex + numTris; ++i)
	{
		Triangle tri = tris[indices[i]];
		// get tri center
		float center = ( (tri.v[0] + tri.v[1] + tri.v[2]) / 3 )[dim];
		sortedTrisByCenter.push_back( std::pair<int, float>(indices[i], center) );
	}
	
	// sort triangles by center in ascending order 
	std::sort(sortedTrisByCenter.begin(), sortedTrisByCenter.end(), [](auto &left, auto &right){return left.second < right.second;});
	
	// go through sorted list of tris: 1. adjust bvh->indices accordingly, 2. assign tri to left or right
	for (int i = 0; i < sortedTrisByCenter.size(); ++i) 
	{
		indices[triIndex + i] = sortedTrisByCenter.at(i).first;
		if (sortedTrisByCenter.at(i).second < pos) left++;
	}

	return std::pair<int, int>(left, numTris - left);
}